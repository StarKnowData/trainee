# multiscale-template-matching
this is a sample for template matching with opencv
