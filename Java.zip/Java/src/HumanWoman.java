public class HumanWoman extends HumanBeings {




    void shout(){
        System.out.print("Woman Shout");
    }

}
