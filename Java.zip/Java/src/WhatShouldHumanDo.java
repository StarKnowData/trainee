public interface WhatShouldHumanDo {


    void cook();
    void work();


}
