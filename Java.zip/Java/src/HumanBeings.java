public class HumanBeings {

    int legs = 0;


    void shout(){
        System.out.println("HumanBeing Shout");
    }

}
