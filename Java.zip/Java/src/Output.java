public class Output {


    public static void main(String[] args){



        HumanBeings hb = new HumanBeings();// 生成一个类的实例，也叫产生一个对象

        hb.shout();

        HumanMan    man1 = new HumanMan();

        man1.shout();
        man1.cook();

        HumanWoman wm1 = new HumanWoman();

        wm1.shout();
        // wm1.cook();


    }


}
