# 飞机大战
利用python实现的小游戏：飞机大战

环境：**python3**+**pygame模块**

![](flygame.png)