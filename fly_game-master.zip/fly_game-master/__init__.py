#Author:LJK
#-*- coding:utf-8 -*-
from __future__ import division
b = 8
c = 4
a = b // c
print a